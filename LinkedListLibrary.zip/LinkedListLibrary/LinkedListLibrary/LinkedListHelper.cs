﻿using System;

using System.Collections.Generic;

namespace LinkedListLibrary
{
    public static class LinkedListHelpers
    {
        public static LinkedList<String> filterDuplicateCharacters(LinkedList<String> list) {

            Console.WriteLine(list);

            return list;
        }
    }
}
