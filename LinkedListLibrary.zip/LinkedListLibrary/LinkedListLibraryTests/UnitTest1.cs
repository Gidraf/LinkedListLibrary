using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using LinkedListLibrary;
namespace LinkedListLibraryTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            LinkedList<char> myList = new LinkedList<char>();
            myList.AddFirst('a');
			myList.AddFirst('a');
			myList.AddFirst('a');
			myList.AddFirst('a');
			myList.AddFirst('a');
			myList.AddFirst('a');
			myList.AddFirst('a');
			myList.AddFirst('a');
            Assert.AreEqual(2, LinkedListLibrary.LinkedListHelpers.deletedDuplicateChar(myList).Count);
		}

        [TestMethod]
        public void TestMethod2()
        {
            LinkedList<char> myList = new LinkedList<char>();
            myList.AddFirst('a');
            myList.AddFirst('c');
            myList.AddFirst('a');
            myList.AddFirst('a');
            myList.AddFirst('c');
            myList.AddFirst('a');
            myList.AddFirst('a');
            myList.AddFirst('a');
            Assert.AreEqual(4, LinkedListLibrary.LinkedListHelpers.deletedDuplicateChar(myList).Count);
        }
    }
}
